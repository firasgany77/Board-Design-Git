DSx Design

reached: 0x00214a7d on first fall. 
reached: 0x00214a7d on second fall.


