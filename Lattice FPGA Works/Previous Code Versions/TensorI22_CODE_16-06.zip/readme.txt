TensorI22_CODE_16-06

- ALL System powers up but there is a PLTRST# fall after 7 sec. 
- BIOS reaches 0x00214A7D